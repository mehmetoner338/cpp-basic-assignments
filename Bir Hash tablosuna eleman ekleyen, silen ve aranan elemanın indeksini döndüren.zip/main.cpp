#include <iostream>
#include <vector>
using namespace std;

class HashTableQP {
private:
    int m;
    vector<int> table;
    const int EMPTY = -1;
    const int DELETED = -2;

    int h(int key) const {
        int x = key % m;
        return (x < 0) ? x + m : x;
    }

public:
    explicit HashTableQP(int size) : m(size), table(size, EMPTY) {}

    bool insert(int key) {
        int idx = h(key);

        for (int i = 0; i < m; i++) {
            int probe = (idx + i * i) % m;

            if (table[probe] == key) return true;
            if (table[probe] == EMPTY || table[probe] == DELETED) {
                table[probe] = key;
                return true;
            }
        }
        return false;
    }

    int searchIndex(int key) const {
        int idx = h(key);

        for (int i = 0; i < m; i++) {
            int probe = (idx + i * i) % m;

            if (table[probe] == key) return probe;
        }
        return -1;
    }

    bool removeKey(int key) {
        int pos = searchIndex(key);
        if (pos == -1) return false;
        table[pos] = DELETED;
        return true;
    }

    void print() const {
        for (int i = 0; i < m; i++) {
            cout << i << ": ";
            if (table[i] == EMPTY) cout << "EMPTY";
            else if (table[i] == DELETED) cout << "DELETED";
            else cout << table[i];
            cout << "\n";
        }
    }
};

int main() {
    HashTableQP ht(11);

    ht.insert(21);
    ht.insert(32);
    ht.insert(43);
    ht.insert(54);
    ht.insert(65);

    int key = 34;
    int idx = ht.searchIndex(key);
    cout << key << " index = " << idx << "\n";

    return 0;
}

