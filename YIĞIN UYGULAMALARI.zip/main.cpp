#include <iostream>
using namespace std;

void yaz(int a[], int n){
    for(int i=0;i<n;i++) cout << a[i] << " ";
    cout << "\n";
}

void kabukSirala(int a[], int n){
    for(int gap = n/2; gap > 0; gap /= 2){
        for(int i = gap; i < n; i++){
            int temp = a[i];
            int j = i;
            while(j >= gap && a[j-gap] > temp){
                a[j] = a[j-gap];
                j -= gap;
            }
            a[j] = temp;
        }
    }
}

int main(){
    int a[] = {7,3,5,8,2,9,4,15,6};
    int n = sizeof(a)/sizeof(a[0]);

    kabukSirala(a, n);
    yaz(a, n);

    return 0;
}

