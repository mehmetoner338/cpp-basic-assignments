#include <iostream>
#include <string>
using namespace std;

struct Node {
    string name;
    Node* next;
    Node(const string& n) : name(n), next(NULL) {}
};

class CircularQueue {
private:
    Node* rear;

public:
    CircularQueue() : rear(NULL) {}

    bool empty() const { return rear == NULL; }

    void enqueue(const string& name) {
        Node* node = new Node(name);
        if (!rear) {
            rear = node;
            rear->next = rear;
        } else {
            node->next = rear->next;
            rear->next = node;
            rear = node;
        }
    }

    string josephus(int k) {
        if (!rear) return "";
        if (k <= 0) k = 1;

        Node* prev = rear;
        Node* cur = rear->next;

        while (cur->next != cur) {
            for (int step = 1; step < k; step++) {
                prev = cur;
                cur = cur->next;
            }

            cout << "Elenen: " << cur->name << "\n";

            prev->next = cur->next;
            if (cur == rear) rear = prev;

            Node* del = cur;
            cur = prev->next;
            delete del;
        }

        rear = cur;
        return cur->name;
    }

    ~CircularQueue() {
        if (!rear) return;
        Node* start = rear->next;
        Node* cur = start;
        do {
            Node* nxt = cur->next;
            delete cur;
            cur = nxt;
        } while (cur != start);
        rear = NULL;
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int n, k;
    cout << "Asker sayisi: ";
    cin >> n;

    CircularQueue q;
    cout << "Asker isimleri:\n";
    for (int i = 0; i < n; i++) {
        string s;
        cin >> s;
        q.enqueue(s);
    }

    cout << "n (sayma adimi): ";
    cin >> k;

    cout << "\nEleme sirasi:\n";
    string winner = q.josephus(k);

    cout << "\nYardima gidecek asker: " << winner << "\n";
    return 0;
}

