#include <iostream>
using namespace std;

long long disDongu, icDongu;

void yaz(int a[], int n){
    for(int i=0;i<n;i++) cout<<a[i]<<" ";
    cout<<"\n";
}
void kopyala(int s[], int d[], int n){
    for(int i=0;i<n;i++) d[i]=s[i];
}

void birlestir(int a[], int l, int m, int r){
    int i=l, j=m+1, k=0;
    int temp[20];
    while(i<=m && j<=r){
        icDongu++;
        if(a[i]>a[j]) temp[k++]=a[i++];
        else temp[k++]=a[j++];
    }
    while(i<=m) temp[k++]=a[i++];
    while(j<=r) temp[k++]=a[j++];
    for(int x=0;x<k;x++) a[l+x]=temp[x];
}
void mergeSort(int a[], int l, int r){
    if(l<r){
        disDongu++;
        int m=(l+r)/2;
        mergeSort(a,l,m);
        mergeSort(a,m+1,r);
        birlestir(a,l,m,r);
    }
}

int parcala(int a[], int low, int high){
    int pivot=a[high], i=low-1;
    for(int j=low;j<high;j++){
        icDongu++;
        if(a[j]>pivot){
            i++;
            int t=a[i]; a[i]=a[j]; a[j]=t;
        }
    }
    int t=a[i+1]; a[i+1]=a[high]; a[high]=t;
    return i+1;
}
void quickSort(int a[], int low, int high){
    if(low<high){
        disDongu++;
        int p=parcala(a,low,high);
        quickSort(a,low,p-1);
        quickSort(a,p+1,high);
    }
}

void heapify(int a[], int n, int i){
    disDongu++;
    int sec=i, l=2*i+1, r=2*i+2;
    if(l<n){ icDongu++; if(a[l]>a[sec]) sec=l; }
    if(r<n){ icDongu++; if(a[r]>a[sec]) sec=r; }
    if(sec!=i){
        int t=a[i]; a[i]=a[sec]; a[sec]=t;
        heapify(a,n,sec);
    }
}
void heapSort(int a[], int n){
    for(int i=n/2-1;i>=0;i--) heapify(a,n,i);
    for(int i=n-1;i>0;i--){
        int t=a[0]; a[0]=a[i]; a[i]=t;
        heapify(a,i,0);
    }
}

int main(){
    int ana[]={2,3,4,5,6,7,8,9,15};
    int n=9, a[20];

    kopyala(ana,a,n);
    disDongu=icDongu=0;
    mergeSort(a,0,n-1);
    cout<<"Birlesme Siralama\nDis Dongu: "<<disDongu<<"  Ic Dongu: "<<icDongu<<"\n";
    yaz(a,n);

    kopyala(ana,a,n);
    disDongu=icDongu=0;
    quickSort(a,0,n-1);
    cout<<"Hizli Siralama\nDis Dongu: "<<disDongu<<"  Ic Dongu: "<<icDongu<<"\n";
    yaz(a,n);

    kopyala(ana,a,n);
    disDongu=icDongu=0;
    heapSort(a,n);
    cout<<"Kumeleme Siralama \nDis Dongu: "<<disDongu<<"  Ic Dongu: "<<icDongu<<"\n";
    yaz(a,n);

    return 0;
}

