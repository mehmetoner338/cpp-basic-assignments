#include <iostream>
using namespace std;

struct Node {
    int value;
    int priority;
    Node* next;
    Node(int v, int p) : value(v), priority(p), next(NULL) {}
};

class PriorityQueue {
private:
    Node* front;

public:
    PriorityQueue() : front(NULL) {}

    bool empty() const { return front == NULL; }

    void enqueue(int value, int priority) {
        Node* n = new Node(value, priority);

        if (!front || priority > front->priority) {
            n->next = front;
            front = n;
            return;
        }

        Node* cur = front;
        while (cur->next && cur->next->priority >= priority) {
            cur = cur->next;
        }

        n->next = cur->next;
        cur->next = n;
    }

    bool dequeue(int &outValue, int &outPriority) {
        if (!front) return false;

        Node* del = front;
        outValue = del->value;
        outPriority = del->priority;

        front = front->next;
        delete del;
        return true;
    }

    bool peek(int &outValue, int &outPriority) const {
        if (!front) return false;
        outValue = front->value;
        outPriority = front->priority;
        return true;
    }

    void display() const {
        Node* cur = front;
        while (cur) {
            cout << "(" << cur->value << ", " << cur->priority << ")";
            if (cur->next) cout << " -> ";
            cur = cur->next;
        }
        cout << "\n";
    }

    ~PriorityQueue() {
        while (front) {
            Node* del = front;
            front = front->next;
            delete del;
        }
    }
};

int main() {
    PriorityQueue pq;

    pq.enqueue(10, 2);
    pq.enqueue(99, 5);
    pq.enqueue(30, 2);
    pq.enqueue(7,  1);
    pq.enqueue(50, 3);

    cout << "Kuyruk: ";
    pq.display();

    int v, p;
    while (pq.dequeue(v, p)) {
        cout << "Cikan: value=" << v << " priority=" << p << "\n";
    }

    return 0;
}

