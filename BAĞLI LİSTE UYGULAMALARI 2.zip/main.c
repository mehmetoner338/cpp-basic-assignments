#include <stdio.h>
#include <ctype.h>

#define MAX 100

typedef struct {
    int dizi[MAX];
    int top;
} Stack;

void push(Stack *s, int x) {
    if (s->top < MAX - 1)
        s->dizi[++s->top] = x;
}

int pop(Stack *s) {
    if (s->top >= 0)
        return s->dizi[s->top--];
    return 0;
}

int postfixHesapla(char ifade[]) {
    Stack s;
    s.top = -1;

    for (int i = 0; ifade[i] != '\0'; i++) {
        if (isdigit(ifade[i])) {
            push(&s, ifade[i] - '0');
        } else if (ifade[i] == '+' || ifade[i] == '-' ||
                   ifade[i] == '*' || ifade[i] == '/') {

            int b = pop(&s);
            int a = pop(&s);

            if (ifade[i] == '+')
                push(&s, a + b);
            else if (ifade[i] == '-')
                push(&s, a - b);
            else if (ifade[i] == '*')
                push(&s, a * b);
            else if (ifade[i] == '/')
                push(&s, a / b);
        }
    }
    return pop(&s);
}

int main() {
    char postfix[100];

    printf("Postfix ifadeyi giriniz: ");
    scanf("%s", postfix);

    printf("Sonuc: %d\n", postfixHesapla(postfix));

    return 0;
}

