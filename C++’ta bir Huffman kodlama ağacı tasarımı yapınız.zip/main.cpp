#include <iostream>
#include <string>
#include <map>
#include <queue>
using namespace std;

struct Node {
    char ch;
    int freq;
    Node *left, *right;
    Node(char c, int f) : ch(c), freq(f), left(NULL), right(NULL) {}
    Node(Node* l, Node* r) : ch('\0'), freq(l->freq + r->freq), left(l), right(r) {}
};

struct Cmp {
    bool operator()(Node* a, Node* b) const {
        return a->freq > b->freq;
    }
};

void buildCodes(Node* root, string cur, map<char, string>& codes) {
    if (!root) return;
    if (!root->left && !root->right) {
        if (cur.size() == 0) cur = "0";
        codes[root->ch] = cur;
        return;
    }
    buildCodes(root->left, cur + "0", codes);
    buildCodes(root->right, cur + "1", codes);
}

int main() {
    string s;
    getline(cin, s);

    map<char, int> freq;
    for (int i = 0; i < (int)s.size(); i++) freq[s[i]]++;

    priority_queue<Node*, std::vector<Node*>, Cmp> pq;
    for (map<char,int>::iterator it = freq.begin(); it != freq.end(); ++it)
        pq.push(new Node(it->first, it->second));

    if (pq.empty()) return 0;

    while (pq.size() > 1) {
        Node* a = pq.top(); pq.pop();
        Node* b = pq.top(); pq.pop();
        pq.push(new Node(a, b));
    }

    Node* root = pq.top();
    map<char, string> codes;
    buildCodes(root, "", codes);

    for (map<char,string>::iterator it = codes.begin(); it != codes.end(); ++it)
        cout << it->first << " " << it->second << "\n";

    return 0;
}
