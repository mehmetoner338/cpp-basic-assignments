#include <iostream>
#include <string>
#include <map>
#include <vector>
#include <algorithm>
using namespace std;

struct Item {
    char ch;
    int freq;
};

struct Node {
    char ch;
    int freq;
    Node *left, *right;
    Node(char c, int f) : ch(c), freq(f), left(NULL), right(NULL) {}
    Node(Node* l, Node* r) : ch('\0'), freq((l?l->freq:0) + (r?r->freq:0)), left(l), right(r) {}
};

bool cmpItem(const Item& a, const Item& b) {
    if (a.freq != b.freq) return a.freq > b.freq;
    return a.ch < b.ch;
}

int bestSplit(const vector<Item>& a, int l, int r) {
    int total = 0;
    for (int i = l; i <= r; i++) total += a[i].freq;

    int leftSum = 0;
    int best = l;
    int bestDiff = 2147483647;

    for (int i = l; i < r; i++) {
        leftSum += a[i].freq;
        int rightSum = total - leftSum;
        int diff = leftSum - rightSum;
        if (diff < 0) diff = -diff;
        if (diff < bestDiff) {
            bestDiff = diff;
            best = i;
        }
    }
    return best;
}

Node* buildSF(const vector<Item>& a, int l, int r) {
    if (l > r) return NULL;
    if (l == r) return new Node(a[l].ch, a[l].freq);

    int mid = bestSplit(a, l, r);
    Node* left = buildSF(a, l, mid);
    Node* right = buildSF(a, mid + 1, r);
    return new Node(left, right);
}

void buildCodes(Node* root, string cur, map<char, string>& codes) {
    if (!root) return;
    if (!root->left && !root->right) {
        if (cur.size() == 0) cur = "0";
        codes[root->ch] = cur;
        return;
    }
    buildCodes(root->left, cur + "0", codes);
    buildCodes(root->right, cur + "1", codes);
}

int main() {
    string s;
    getline(cin, s);

    map<char, int> freq;
    for (int i = 0; i < (int)s.size(); i++) freq[s[i]]++;

    vector<Item> items;
    for (map<char,int>::iterator it = freq.begin(); it != freq.end(); ++it) {
        Item x; x.ch = it->first; x.freq = it->second;
        items.push_back(x);
    }

    sort(items.begin(), items.end(), cmpItem);

    if (items.size() == 0) return 0;

    Node* root = buildSF(items, 0, (int)items.size() - 1);
    map<char, string> codes;
    buildCodes(root, "", codes);

    for (map<char,string>::iterator it = codes.begin(); it != codes.end(); ++it)
        cout << it->first << " " << it->second << "\n";

    return 0;
}
