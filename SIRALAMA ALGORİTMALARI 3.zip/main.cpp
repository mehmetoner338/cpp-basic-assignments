#include <iostream>
using namespace std;

void diziYaz(int d[], int n) {
    for (int i = 0; i < n; i++)
        cout << d[i] << " ";
    cout << endl;
}

void diziKopyala(int kaynak[], int hedef[], int n) {
    for (int i = 0; i < n; i++)
        hedef[i] = kaynak[i];
}

/* a) Araya Ekleme S�ralama */
void arayaEkleme(int d[], int n, bool kucuktenBuyuge) {
    int disDongu = 0, icDongu = 0;

    for (int i = 1; i < n; i++) {
        disDongu++;
        int anahtar = d[i];
        int j = i - 1;

        while (j >= 0 && (kucuktenBuyuge ? d[j] > anahtar : d[j] < anahtar)) {
            icDongu++;
            d[j + 1] = d[j];
            j--;
        }
        d[j + 1] = anahtar;
    }

    cout << "Araya Ekleme -> Dis dongu: " << disDongu
         << " Ic dongu: " << icDongu << endl;
}

/* b) Secmeli Siralama */
void secmeli(int d[], int n, bool kucuktenBuyuge) {
    int disDongu = 0, icDongu = 0;

    for (int i = 0; i < n - 1; i++) {
        disDongu++;
        int secilen = i;

        for (int j = i + 1; j < n; j++) {
            icDongu++;
            if (kucuktenBuyuge ? d[j] < d[secilen] : d[j] > d[secilen])
                secilen = j;
        }

        int tmp = d[i];
        d[i] = d[secilen];
        d[secilen] = tmp;
    }

    cout << "Secmeli -> Dis dongu: " << disDongu
         << " Ic dongu: " << icDongu << endl;
}

/* c) Kabarcik Siralama */
void kabarcik(int d[], int n, bool kucuktenBuyuge) {
    int disDongu = 0, icDongu = 0;

    for (int i = 0; i < n - 1; i++) {
        disDongu++;
        for (int j = 0; j < n - 1 - i; j++) {
            icDongu++;
            if (kucuktenBuyuge ? d[j] > d[j + 1] : d[j] < d[j + 1]) {
                int tmp = d[j];
                d[j] = d[j + 1];
                d[j + 1] = tmp;
            }
        }
    }

    cout << "Kabarcik -> Dis dongu: " << disDongu
         << " Ic dongu: " << icDongu << endl;
}

int main() {
    int anaDizi[] = {2,3,4,5,6,7,8,9,15};
    int n = 9;
    int d[20];

    cout << "=== 1) BUYUKTEN KUCUYE SIRALAMA ===" << endl;
    diziKopyala(anaDizi, d, n);
    arayaEkleme(d, n, false);
    diziYaz(d, n);

    diziKopyala(anaDizi, d, n);
    secmeli(d, n, false);
    diziYaz(d, n);

    diziKopyala(anaDizi, d, n);
    kabarcik(d, n, false);
    diziYaz(d, n);

    cout << "\n=== 2) KUCUKTEN BUYUGE SIRALAMA ===" << endl;
    diziKopyala(anaDizi, d, n);
    arayaEkleme(d, n, true);
    diziYaz(d, n);

    diziKopyala(anaDizi, d, n);
    secmeli(d, n, true);
    diziYaz(d, n);

    diziKopyala(anaDizi, d, n);
    kabarcik(d, n, true);
    diziYaz(d, n);

    return 0;
}

