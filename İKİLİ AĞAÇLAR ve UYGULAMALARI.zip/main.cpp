#include <iostream>
#include <string>
using namespace std;

struct Node {
    char ch;
    Node* left;
    Node* right;
    Node(char c) : ch(c), left(NULL), right(NULL) {}
};

Node* insertNode(Node* root, char c) {
    if (root == NULL) return new Node(c);
    if (c < root->ch) root->left = insertNode(root->left, c);
    else root->right = insertNode(root->right, c);
    return root;
}

void inorder(Node* root) {
    if (root == NULL) return;
    inorder(root->left);
    cout << root->ch;
    inorder(root->right);
}

int main() {
    string s;
    getline(cin, s);

    Node* root = NULL;
    for (int i = 0; i < (int)s.size(); i++) {
        char c = s[i];
        if (c == ' ') continue;
        root = insertNode(root, c);
    }

    inorder(root);
    cout << "\n";
    return 0;
}

